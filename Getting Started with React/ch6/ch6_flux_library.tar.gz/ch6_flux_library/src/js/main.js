var App = require('./components/app');
var React = require('react');
var ReactDom = require('react-dom');

ReactDom.render(<App />, document.getElementById('main'));

